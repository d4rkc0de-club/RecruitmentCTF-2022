module.exports = {
  checkanswer: function (a) {
    if (a === "Goku,Vegetta,Krillin,Chi-Chi,Bulma,Android 18") {
      return true;
    }
    if (a === "Goku,Vegetta,Gohan,Chi-Chi,Bulma,Videl") {
      return true;
    }
    return false;
  }
};
