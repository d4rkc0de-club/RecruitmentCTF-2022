const express = require("express");
const path = require("path");
const vm = require("vm");
var bodyParser = require('body-parser');


const app = express();
app.engine("pug", require("pug").__express);
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); 
app.get("/",function(req,res,next){
    res.render("index");
});
app.get("/login",function(req,res,next){
  res.render("login");
});
app.post("/login",function(req,res,next){
  res.render("login");
});

app.post("/", function (req, res, next) {
  let output = "Better luck next try";
  if (req.body.code && req.body.code1 && req.body.code2) {
  const code = req.body.code + "";
  const code1 = req.body.code1 + "";
  const code2 = req.body.code2 + "";
  if (code.length <= 12 && code1.length <= 12 && code2.length <= 35) {
    try {
      let context = {
        pair: [
          ["Goku", "Vegetta", "Krillin"],
          ["Chi-Chi", "Bulma", "Videl"]
        ],
        answer: "incorrect",
        require
      };
      vm.runInNewContext(
        `'use strict';
        (function ()
        {
          pair[${code}][${code1}]=${code2};
          let ans=pair.toString();
          let checker=require('./check.js')
          if(checker.checkanswer(ans)===true){
            answer="correct"
          }
          else{
            answer="incorrect"
          }
        })()`,
        context
      );
      if (context.answer === "correct") {
        res.render("flag");
      } 
      else if(req.body.hide) {
        const code3 = req.body.hide + "";
        let new_context = {
          pair: context.pair,
          answer: context.answer
        };
        const result = vm.runInNewContext(
          `'use strict';
          (function ()
          {
            return ${code3}
          })()`,
          new_context
        );
        output = result;
        console.log(output)
        res.render("index", { output });
      }
      else{
        res.render("index", { output });

      }
    } catch (e) {
      output = "Error occurred";
      res.render("index", { output });
      process.exit(1);
    }
  } 
  else {
    output = "Character limit exceded";
    res.render("index", { output });
  }
}
else{
    output = "";
    res.render("index", { output });
}
});
app.get('/robots.txt',function (req, res) {
  res.render("robots");
});
app.get('/Shenron',function (req, res) {
  res.sendFile(__dirname +'/index.js');
});
app.listen(8080, function () {
  console.log("server running on 8080");
});
